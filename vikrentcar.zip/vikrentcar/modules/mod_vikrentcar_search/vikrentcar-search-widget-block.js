(function(wp) {
	'use strict';

	// support the VikRentCar Search widget as block
	window.vrcRegisterBlockEditor(
		window.MOD_VIKRENTCAR_SEARCH_BLOCK_DATA
	);

})(window.wp);