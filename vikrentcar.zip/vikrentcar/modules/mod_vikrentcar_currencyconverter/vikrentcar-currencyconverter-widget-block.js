(function(wp) {
	'use strict';

	// support the VikRentCar Currency Converter widget as block
	window.vrcRegisterBlockEditor(
		window.MOD_VIKRENTCAR_CURRENCYCONVERTER_BLOCK_DATA
	);

})(window.wp);