(function(wp) {
	'use strict';

	// support the VikRentCar Cars widget as block
	window.vrcRegisterBlockEditor(
		window.MOD_VIKRENTCAR_CARS_BLOCK_DATA
	);

})(window.wp);