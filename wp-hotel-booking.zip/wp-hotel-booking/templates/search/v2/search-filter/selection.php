<?php
if ( ! isset( $data ) ) {
	return;
}
?>
<div class="hb-selection-field">
    <h3><?php esc_html_e( 'Selected', 'wp-hotel-booking' ); ?></h3>
    <ul class="list">
    </ul>
</div>
