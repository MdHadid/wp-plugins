<?php

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;

class WPHB_Admin_Metabox_Product_Review{
	public function __construct() {
//		die;
	}
}
