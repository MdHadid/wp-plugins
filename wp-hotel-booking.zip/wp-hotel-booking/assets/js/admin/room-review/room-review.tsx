import hbReviewImages from "./images"
import hbAdvancedReview from "./advanced-review"

addEventListener("DOMContentLoaded", (event) => {
    hbReviewImages();
    hbAdvancedReview();
});
