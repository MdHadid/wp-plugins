(function(wp) {
	'use strict';

	// support the VikBooking Horizontal Search widget as block
	window.vboRegisterBlockEditor(
		window.MOD_VIKBOOKING_HORIZONTALSEARCH_BLOCK_DATA
	);

})(window.wp);