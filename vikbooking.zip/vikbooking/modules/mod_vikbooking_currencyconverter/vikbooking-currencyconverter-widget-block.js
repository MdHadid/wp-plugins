(function(wp) {
	'use strict';

	// support the VikBooking Currency Converter widget as block
	window.vboRegisterBlockEditor(
		window.MOD_VIKBOOKING_CURRENCYCONVERTER_BLOCK_DATA
	);

})(window.wp);